import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="w-64 min-h-screen bg-gray-100 p-4 border-r">
      <h1 className="text-2xl font-bold mb-4"></h1>
    </div>
  );
};

export default Home;
